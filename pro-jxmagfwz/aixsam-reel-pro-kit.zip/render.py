"""python3 render.py             -> reel.mp4: renders in parallel parts, then adds the voice + sound effects
   python3 render.py shots 2,5,9 -> shot_2.0.jpg ... test frames to check before the full render
   python3 render.py cover       -> cover.jpg (1080x1920) from cover.html
   PARTS=2 python3 render.py     -> fewer parallel parts (use on a slow laptop; default = up to 4)"""
import os, subprocess, sys, wave
from pathlib import Path
import numpy as np
from playwright.sync_api import sync_playwright

FPS, SR = 30, 44100

def with_page(fn, html='reel.html'):
    with sync_playwright() as p:
        browser = p.chromium.launch(); page = browser.new_page(viewport={'width': 1080, 'height': 1920})
        errors = []; page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(Path(html).resolve().as_uri()); page.wait_for_load_state('networkidle')
        assert not errors, errors
        try: return fn(page)
        finally: browser.close()

def render_part(i, n):
    def go(page):
        total = int(page.evaluate('DURATION') * FPS); a, b = i * total // n, (i + 1) * total // n
        ff = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'image2pipe', '-c:v', 'mjpeg', '-r', str(FPS), '-i', '-',
                               '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-pix_fmt', 'yuv420p', f'part_{i}.mp4'],
                              stdin=subprocess.PIPE)
        for k in range(a, b):
            page.evaluate(f'setT({k / FPS})'); ff.stdin.write(page.screenshot(type='jpeg', quality=92))
            if (k - a) % 300 == 0: print(f'part {i + 1}/{n}: frame {k - a}/{b - a}', flush=True)
        ff.stdin.close(); ff.wait()
    with_page(go)

def sound(events, dur):
    """Voice + generated sound effects (no audio files needed)."""
    rng = np.random.default_rng(3); mix = np.zeros(int((dur + 1) * SR), np.float32)
    def env(n, r): t = np.arange(n) / SR; return np.minimum(t / .004, 1) * np.exp(-t / r)
    def tone(f, d, r, g): n = int(d * SR); return np.sin(2 * np.pi * f * np.arange(n) / SR) * env(n, r) * g
    def noise(d, r, g, lp):
        x = rng.standard_normal(int(d * SR)); y = np.zeros_like(x); v = 0
        for k in range(len(x)): v += lp * (x[k] - v); y[k] = v
        return y / (np.abs(y).max() + 1e-9) * env(len(x), r) * g
    def whoosh():
        n = int(.3 * SR); x = rng.standard_normal(n); y = np.zeros(n); v = 0
        for k in range(n): v += (.02 + .25 * k / n) * (x[k] - v); y[k] = v
        return y / np.abs(y).max() * np.sin(np.linspace(0, np.pi, n)) ** 2 * .1
    def mx(*xs):
        o = np.zeros(max(len(x) for x in xs))
        for x in xs: o[:len(x)] += x
        return o
    S = {'whoosh': whoosh(), 'pop': mx(tone(880, .09, .025, .07), tone(1320, .06, .015, .03)), 'soft': tone(660, .07, .02, .025),
         'tick': tone(2400, .02, .005, .04), 'thud': mx(tone(70, .35, .12, .5), noise(.25, .05, .25, .08)), 'swish': noise(.2, .06, .05, .5)}
    def put(t, s): k = int(max(0, t) * SR); j = min(len(mix), k + len(s)); mix[k:j] += s[:j - k]
    for t, kind in sorted(set((round(t, 2), k) for t, k in events)):
        if kind == 'type':
            for q in np.arange(t, t + .9, .07): put(q, tone(3000 + rng.integers(-300, 300), .015, .004, .025))
        elif kind == 'tick':
            for q in np.arange(t, t + 1, .08): put(q, S['tick'])
        else: put(t - (.14 if kind == 'whoosh' else 0), S[kind])
    vo = subprocess.run(['ffmpeg', '-v', 'error', '-i', 'vo.wav', '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'],
                        capture_output=True, check=True).stdout
    vo = np.frombuffer(vo, np.int16).astype(np.float32) / 32768; mix[:len(vo)] += vo[:len(mix)]
    with wave.open('mix.wav', 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(mix, -1, 1) * 32767).astype(np.int16).tobytes())

mode = sys.argv[1] if len(sys.argv) > 1 else 'reel'
if mode == 'part':
    render_part(int(sys.argv[2]), int(sys.argv[3]))
elif mode == 'shots':
    def shots(page):
        for t in sys.argv[2].split(','):
            page.evaluate(f'setT({t})'); page.screenshot(path=f'shot_{float(t):.1f}.jpg', type='jpeg', quality=85)
    with_page(shots); print('saved test frames')
elif mode == 'cover':
    with_page(lambda page: page.screenshot(path='cover.jpg', type='jpeg', quality=92), 'cover.html'); print('done: cover.jpg')
else:
    n = int(os.environ.get('PARTS', min(4, os.cpu_count() or 2)))
    procs = [subprocess.Popen([sys.executable, __file__, 'part', str(i), str(n)]) for i in range(n)]
    events, dur = with_page(lambda page: (page.evaluate('EVENTS'), page.evaluate('DURATION')))
    sound(events, dur)
    assert all(p.wait() == 0 for p in procs), 'a render part failed (see the error above)'
    Path('parts.txt').write_text(''.join(f"file 'part_{i}.mp4'\n" for i in range(n)))
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', 'parts.txt', '-i', 'mix.wav', '-c:v', 'copy',
                    '-af', 'apad', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', 'reel.mp4'], check=True)
    for i in range(n): os.remove(f'part_{i}.mp4')
    print('done: reel.mp4')

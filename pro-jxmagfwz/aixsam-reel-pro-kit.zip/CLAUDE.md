# Reel Pipeline Pro Kit: instructions for Claude

You are making a vertical reel (1080×1920, 30 fps) for the user with this kit, the way @aixsam.dev makes its reels:
reference reel + tool link → research → script (user approves) → voice (user records) → word timings → talking mascot
→ animated scenes → reel.mp4 + cover + caption. The user decides; you do the work.
Honesty first: never invent a number, a feature, a price or a quote. Every claim on screen comes from a real source.

## Files
- `script.txt`: exactly what the voice says. Numbers written as words. Hinglish in English letters, as it sounds.
- `build.py`: `python3 build.py check` prints what the recording says; `python3 build.py` writes `data.js`
  (word times, mouth closed/half/open per frame, blinks, loudness).
- `reel.html`: the reel. Scenes = `<section class=scene data-from="@word" data-bg="#color">`. Elements: `data-at="@word"`
  (`@word#2` = 2nd time, `@word+0.3`, or seconds after scene start), `data-anim` = pop | stamp | up | fade | type | count (data-to) | strike,
  `data-out="@word"`. Poses: `<img src="pose-x.png" data-at="@word" data-dur="1.5">` inside `#poses`. `setT(t)` draws frame t.
- `render.py`: `python3 render.py shots 2,5,9` test frames · `python3 render.py` → reel.mp4 (parallel parts + sound effects) · `python3 render.py cover` → cover.jpg.
- `cover.html`: the cover template. `mascot-closed.png`, `mascot-open.png`, `mascot-blink.png`, `pose-*.png`: the character (placeholders until the user uploads theirs).
- The example `script.txt` / `reel.html` show every template (crossed-out price, typing terminal, count-up, stamp, pose). Replace their content for each new reel; keep the engine (the `<script>` part).

## 0. Setup (do this first, quietly)
1. Unzip the kit if it's a zip; work in that folder.
2. Check `python3 --version`, `ffmpeg -version`, `python3 -c "import pocketsphinx, numpy, playwright"`.
   Install what's missing: `pip install pocketsphinx numpy playwright` then `python3 -m playwright install chromium`
   (add `--break-system-packages` if pip refuses; ffmpeg via brew / apt / winget).
3. If something can't run where you are (no internet, no browser), say so in ONE line and continue: you'll still write every file,
   and at the end the user runs the commands on their own computer.
4. Ask the user, in one message:
   - the reference reel: transcript, video or screenshots
   - the tool / topic link (GitHub repo, official page)
   - language (English / Hinglish), comment keyword, their handle
   - their mascot pictures if they have them: mouth closed, mouth open, eyes closed (optional), plus any reaction poses
     (thumbs up, pointing, shocked…), same character, transparent or plain background

## 1. Research
- Read the tool's real sources: README (also raw.githubusercontent.com/<owner>/<repo>/main/README.md), docs, official pricing page.
- Make a fact list: each fact + where it came from. GitHub stars / prices change: note the date you saw them.
- Study the reference reel for its BEATS (hook → reveal → features → proof → CTA), length and rhythm. Don't copy its words or its unsupported claims.

## 2. Script → wait for approval
- 35–45 s, about 90–110 words, one idea per sentence, simple spoken words. One line per feature; cut the weakest beat.
- The first sentence is the hook and must have all four: SUBJECT (you / I / developers), ACTION (replace, cut, build…),
  RESULT (what they get), and a TRUE CONTRAST (before → after, from the sources: ₹2,000/month → ₹0, 2 hours → 2 minutes).
  Weak: "This tool is amazing." Strong: "I replaced a ₹2,000-a-month app with a free GitHub repo, and it runs on my laptop."
- Show the reveal (the tool's name / repo) within the first ~3 seconds.
- End with: Comment "<KEYWORD>" and I'll send you the link.
- Send the user: the script, one line "subject · action · result · contrast", and the fact list with sources. STOP until they approve.

## 3. Voice → wait for the audio
- Save the approved script in `script.txt` (numbers as words).
- Give the user the exact text for their voice tool (ElevenLabs, any TTS, or to read themselves). Don't generate a voice unless asked.
- When the file arrives: `ffmpeg -y -i <file> -ac 1 -ar 44100 vo.wav` (longer than ~50 s? offer `-af atempo=1.15`).
- `python3 build.py check` and compare with script.txt: AI voices sometimes add, drop or change words. Make script.txt match the audio.
- `python3 build.py`. "matched X of Y words" = script and audio still differ: fix and rerun.

## 4. Mascot
- Save the user's pictures as `mascot-closed.png`, `mascot-open.png`, `mascot-blink.png` (optional) and `pose-<name>.png`, all the same size (~900×900).
- Green background? Key it out with Pillow (alpha from how much green beats red/blue).
- If the face jumps between closed and open (the image AI moved pixels), make the open picture = the closed picture with ONLY the
  mouth area pasted from the open one (soft ellipse mask). Same for the eyes in the blink picture.

## 5. Scenes (reel.html)
- One scene per beat (data-from = the first word of that beat), a different data-bg colour per scene, and a visual change every 2–3 s.
- Elements appear ON the word that introduces them, never before with a placeholder value. A count-up starts on the word that says the number.
- Real proof over decoration: repo name, real numbers with their source in small text, real commands, real screenshots (`<img>`).
  Anything illustrative gets a small "example" label.
- Phone-readable: text ≥ 40px (main text 60px+), one idea per scene, nothing below top:900px (captions + mascot live there).
- Poses: 3–4 per reel on key beats (hook surprise, payoff number, CTA), 1.2–1.8 s each; talking mascot the rest of the time.
- Edit `#handle` to the user's handle.
- Cue words must exist in script.txt (`@word#2` for repeats). The page throws an error for a wrong cue.

## 6. Check, then render
- `python3 render.py shots <one time inside every beat>` and LOOK at every frame: overlapping or cut-off text, a card showing
  before its word, empty-looking gaps, anything on screen that contradicts what the voice says at that moment. Fix, repeat.
- `python3 render.py` → reel.mp4 (slow laptop: `PARTS=2 python3 render.py`). Give the user the file.
- If you couldn't render here: give the user the finished folder (zip) and: `python3 build.py`, `python3 render.py`, `python3 render.py cover`.

## 7. Cover + caption
- Edit cover.html: 3–6 word headline with the contrast (one word in gold), a FREE/₹0-style stamp, a pose picture, a pill with the tool name,
  the handle. Keep headline, stamp and pill between y 285 and 1635 (Instagram's grid crop). `python3 render.py cover`.
- Caption, in the reel's language: line 1 = the hook with the contrast (under ~125 characters, it shows before "more"),
  then one emoji line per feature, one honest line (the catch / limits / "it only drafts"), `Comment "<KEYWORD>"`, 5 hashtags.
- Posting tips to pass on: add a trending sound at low volume, turn on the platform's AI label (AI voice + mascot).

## Changes later
The user can ask for anything in plain words ("bigger hook card", "add the GitHub stars on beat 2"). Edit, check shots, re-render.

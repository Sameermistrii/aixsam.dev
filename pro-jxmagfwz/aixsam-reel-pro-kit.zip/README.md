# Reel Pipeline Pro Kit · @aixsam.dev

## Easiest: one prompt
1. Open Claude (Claude Code in the desktop app is best; Claude chat works too, with web search + code execution turned on).
2. Attach this zip (and your mascot pictures if you have them).
3. Paste everything in PROMPT.txt. Claude does the rest and asks you for what it needs.

## By hand
    pip install pocketsphinx numpy playwright
    python3 -m playwright install chromium        # plus ffmpeg: brew / apt / winget
    ffmpeg -i voice.mp3 -ac 1 -ar 44100 vo.wav     # your voice for script.txt
    python3 build.py check                         # did the voice change any words?
    python3 build.py                               # word timings + mouth + blinks -> data.js
    python3 render.py shots 2,5,9                  # test frames
    python3 render.py                              # reel.mp4 (parallel + sound effects)
    python3 render.py cover                        # cover.jpg

How to write scenes, cues, animations and poses: the comment at the top of reel.html and CLAUDE.md.
Stuck? DM @aixsam.dev on Instagram with your payment ID and a screenshot.
Personal use; please don't resell or re-upload this kit.
